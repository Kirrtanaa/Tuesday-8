import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { UserServiceService } from '../user-service.service';
// import { EditTechnology } from '../addskill';

import { Router } from '@angular/router';


@Component({
  selector: 'app-edit-technology',
  templateUrl: './edit-technology.component.html',
  styleUrls: ['./edit-technology.component.css']
})
export class EditTechnologyComponent implements OnInit {

  adminmainprint:number = 0;
  adder:string;
  minus:string;
  
  discount:  number = 0;
  addprice: number = 0;
  
  private technologies: string[];
  private users: string[];
  private mentor: string[];
  
  constructor(private httpservice : UserServiceService,private router: Router) {
   }

   ngOnInit() {
    this.showtech();
    this.reloadData();
  }
    // this.httpservice.get('../../assets/mentordetails.json').subscribe(

    //   data=>{
    //     this.mentor = data as string[];
    //   },
    //   (err : HttpErrorResponse) => {
    //     console.log(err.message);
    //   }
    

   
  //   this.httpservice.get('../../assets/userdetails.json').subscribe(

  //     data=>{
  //       this.users = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )

  // }


  

   include()
  {
    if(this.adder!=""){
    this.httpservice.savetechnology(this.adder).subscribe(data=>console.log(data),error=>console.log(error));
    this.adder = "";
    } 
    
  }
  exclude() {
    if(this.minus!=""){
      this.httpservice.removetechnology(this.minus).subscribe(data=>console.log(data),error=>console.log(error));
      this.minus = "";
      }
  }

  showtech(){
    this.httpservice.displaytechnology().subscribe(value=>this.technologies=value as string[]);
  }

  reloadData() {
    this.httpservice.getblockusers().subscribe(value=>this.mentor=value as string[]);
  }

  // adddelete(){
  //   if(this.adder!=null) this.technologies.push(this.adder);
  //   if(this.minus!=null) {
  //     for(let find=0;find<this.technologies.length;find++){
  //       if(this.technologies[find]==this.minus) {
  //         this.technologies.splice(find,1);
  //         break;
  //       }
  //     }++
  //   }
  //   this.adder = null;
  //   this.minus = null;
  // }

  tech(){
    this.adminmainprint = 1;
  }

  editt(){
    this.adminmainprint = 2;
  }
  report(){
    this.adminmainprint = 3;
  }
  goback(){
    // localStorage.removeItem('Adminmainpage');
    this.router.navigate(['/login']);
  }
  price(){
    this.discount = 0;
    this.addprice = 0;
  }

}
