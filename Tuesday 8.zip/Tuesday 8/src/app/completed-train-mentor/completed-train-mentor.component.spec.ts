import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompletedTrainMentorComponent } from './completed-train-mentor.component';

describe('CompletedTrainMentorComponent', () => {
  let component: CompletedTrainMentorComponent;
  let fixture: ComponentFixture<CompletedTrainMentorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompletedTrainMentorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompletedTrainMentorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
