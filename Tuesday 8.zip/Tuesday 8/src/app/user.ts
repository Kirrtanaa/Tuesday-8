export class CurrentTraining {
    trainername: string;
    course: string;
    completion: Int16Array;
}