import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorLoggedComponent } from './mentor-logged.component';

describe('MentorLoggedComponent', () => {
  let component: MentorLoggedComponent;
  let fixture: ComponentFixture<MentorLoggedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorLoggedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorLoggedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
